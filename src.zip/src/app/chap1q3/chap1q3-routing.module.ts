import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap1q3Page } from './chap1q3.page';

const routes: Routes = [
  {
    path: '',
    component: Chap1q3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap1q3PageRoutingModule {}
