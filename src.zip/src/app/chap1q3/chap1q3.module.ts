import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q3PageRoutingModule } from './chap1q3-routing.module';

import { Chap1q3Page } from './chap1q3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q3PageRoutingModule
  ],
  declarations: [Chap1q3Page]
})
export class Chap1q3PageModule {}
