import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap1q3Page } from './chap1q3.page';

describe('Chap1q3Page', () => {
  let component: Chap1q3Page;
  let fixture: ComponentFixture<Chap1q3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap1q3Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap1q3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
