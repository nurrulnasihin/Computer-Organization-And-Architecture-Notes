import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q3',
  templateUrl: './chap1q3.page.html',
  styleUrls: ['./chap1q3.page.scss'],
})
export class Chap1q3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
