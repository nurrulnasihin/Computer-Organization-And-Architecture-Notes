import { Component } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';
import { Answer1Page } from '../answer1/answer1.page';
import { Router } from '@angular/router';


@Component({
  selector: 'app-questionanswer',
  templateUrl: './questionanswer.page.html',
  styleUrls: ['./questionanswer.page.scss'],
  providers: [NavParams]

})
export class QuestionanswerPage {

  //  public text:string="";

  constructor(public router:Router, public navCtrl: NavController, public navParams: NavParams) 
  {

    }
  
  goAnswer1Page() {
    this.router.navigate(['answer1'],{queryParams:{id:1,name:"xyz"}});
  }

}

    



