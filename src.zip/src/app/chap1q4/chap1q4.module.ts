import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q4PageRoutingModule } from './chap1q4-routing.module';

import { Chap1q4Page } from './chap1q4.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q4PageRoutingModule
  ],
  declarations: [Chap1q4Page]
})
export class Chap1q4PageModule {}
