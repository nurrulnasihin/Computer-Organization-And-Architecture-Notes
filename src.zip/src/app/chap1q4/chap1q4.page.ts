import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q4',
  templateUrl: './chap1q4.page.html',
  styleUrls: ['./chap1q4.page.scss'],
})
export class Chap1q4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
