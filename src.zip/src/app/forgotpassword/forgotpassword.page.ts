import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.page.html',
  styleUrls: ['./forgotpassword.page.scss'],
})
export class ForgotpasswordPage implements OnInit {

  constructor(private afAuth:AngularFireAuth) { }

  ngOnInit() {
  }

  reset(email){
    this.afAuth.sendPasswordResetEmail(email);
  }

}
