import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Quiz6PageRoutingModule } from './quiz6-routing.module';

import { Quiz6Page } from './quiz6.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Quiz6PageRoutingModule
  ],
  declarations: [Quiz6Page]
})
export class Quiz6PageModule {}
