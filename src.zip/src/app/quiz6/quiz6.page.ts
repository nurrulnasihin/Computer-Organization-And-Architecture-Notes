import { Component, ViewChild } from '@angular/core';
import { IonSlides,AlertController } from '@ionic/angular';


@Component({
  selector: 'app-quiz6',
  templateUrl: './quiz6.page.html',
  styleUrls: ['./quiz6.page.scss'],
})
export class Quiz6Page  {


  @ViewChild('mySlider') slides : IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  constructor(private alertCtrl: AlertController) {}
  async correctAnswer(){
    await this.alertCtrl.create({
    header: "Congratulation!",
    subHeader:"That answer is correct.",
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "Okay"
    }
    ]
    }).then(res => res.present());
}

// question1
async wrongAnswer1(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : data that has been processed into information",
  message:"Explanation: Raw material will become information after it has been processed",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question2
async wrongAnswer2(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : Communication",
message:"Explanation: External device can be classify into human readable, machine readable and communication",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question3
async wrongAnswer3(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : All of the above",
message:"Explanation: Input Output Techniques are Programmed, interrupt Driven and Direct Memory Access",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question4
async wrongAnswer4(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : as an additional module on bus",
message:"Explanation: one of DMA Function is as an additional module on bus",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question5
async wrongAnswer5(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : False",
message:"Explanation: I/O Module functions are: Control & Timing, CPU Communication, Device Communication, data Buffering, Error Detection",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}
//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

}


