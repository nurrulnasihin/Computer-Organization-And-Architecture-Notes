import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap3q2Page } from './chap3q2.page';

describe('Chap3q2Page', () => {
  let component: Chap3q2Page;
  let fixture: ComponentFixture<Chap3q2Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap3q2Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap3q2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
