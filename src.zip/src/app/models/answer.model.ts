export class Answer  {
  _id: string;
  answer: string;
  questionId: string;
  positiveVotes: number;
  negativeVotes: number;
  createdDate: Date;
}
