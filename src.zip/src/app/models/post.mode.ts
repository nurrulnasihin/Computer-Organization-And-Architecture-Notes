export interface Post {
    id?:any;
    title: string;
    description: string;
 }