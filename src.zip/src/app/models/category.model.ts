export class Category  {
  _id: string;
  slug: string;
  title: string;
  description: string;
  color: string;
}
