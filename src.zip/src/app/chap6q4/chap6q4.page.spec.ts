import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap6q4Page } from './chap6q4.page';

describe('Chap6q4Page', () => {
  let component: Chap6q4Page;
  let fixture: ComponentFixture<Chap6q4Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap6q4Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap6q4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
