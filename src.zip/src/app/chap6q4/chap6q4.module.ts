import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap6q4PageRoutingModule } from './chap6q4-routing.module';

import { Chap6q4Page } from './chap6q4.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap6q4PageRoutingModule
  ],
  declarations: [Chap6q4Page]
})
export class Chap6q4PageModule {}
