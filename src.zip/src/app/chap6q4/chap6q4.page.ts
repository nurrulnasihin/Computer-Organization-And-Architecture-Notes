import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap6q4',
  templateUrl: './chap6q4.page.html',
  styleUrls: ['./chap6q4.page.scss'],
})
export class Chap6q4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
