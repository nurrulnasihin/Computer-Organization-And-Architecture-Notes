import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap5q3Page } from './chap5q3.page';

const routes: Routes = [
  {
    path: '',
    component: Chap5q3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap5q3PageRoutingModule {}
