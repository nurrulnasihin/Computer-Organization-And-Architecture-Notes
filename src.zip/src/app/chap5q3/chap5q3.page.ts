import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap5q3',
  templateUrl: './chap5q3.page.html',
  styleUrls: ['./chap5q3.page.scss'],
})
export class Chap5q3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
