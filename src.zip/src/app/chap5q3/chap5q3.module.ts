import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap5q3PageRoutingModule } from './chap5q3-routing.module';

import { Chap5q3Page } from './chap5q3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap5q3PageRoutingModule
  ],
  declarations: [Chap5q3Page]
})
export class Chap5q3PageModule {}
