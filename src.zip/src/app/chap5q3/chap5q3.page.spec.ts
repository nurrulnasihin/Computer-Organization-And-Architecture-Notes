import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap5q3Page } from './chap5q3.page';

describe('Chap5q3Page', () => {
  let component: Chap5q3Page;
  let fixture: ComponentFixture<Chap5q3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap5q3Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap5q3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
