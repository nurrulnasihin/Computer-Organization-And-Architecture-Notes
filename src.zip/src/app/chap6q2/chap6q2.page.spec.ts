import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap6q2Page } from './chap6q2.page';

describe('Chap6q2Page', () => {
  let component: Chap6q2Page;
  let fixture: ComponentFixture<Chap6q2Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap6q2Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap6q2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
