import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap6q2',
  templateUrl: './chap6q2.page.html',
  styleUrls: ['./chap6q2.page.scss'],
})
export class Chap6q2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
