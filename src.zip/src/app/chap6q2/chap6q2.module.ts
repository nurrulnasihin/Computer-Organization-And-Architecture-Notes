import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap6q2PageRoutingModule } from './chap6q2-routing.module';

import { Chap6q2Page } from './chap6q2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap6q2PageRoutingModule
  ],
  declarations: [Chap6q2Page]
})
export class Chap6q2PageModule {}
