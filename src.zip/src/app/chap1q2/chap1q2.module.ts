import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q2PageRoutingModule } from './chap1q2-routing.module';

import { Chap1q2Page } from './chap1q2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q2PageRoutingModule
  ],
  declarations: [Chap1q2Page]
})
export class Chap1q2PageModule {}
