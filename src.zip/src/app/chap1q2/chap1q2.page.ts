import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q2',
  templateUrl: './chap1q2.page.html',
  styleUrls: ['./chap1q2.page.scss'],
})
export class Chap1q2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
