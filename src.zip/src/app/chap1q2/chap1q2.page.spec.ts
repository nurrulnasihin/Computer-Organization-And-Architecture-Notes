import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap1q2Page } from './chap1q2.page';

describe('Chap1q2Page', () => {
  let component: Chap1q2Page;
  let fixture: ComponentFixture<Chap1q2Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap1q2Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap1q2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
