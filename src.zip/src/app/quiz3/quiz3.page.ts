import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides, AlertController } from '@ionic/angular';


@Component({
  selector: 'app-quiz3',
  templateUrl: './quiz3.page.html',
  styleUrls: ['./quiz3.page.scss'],
})
export class Quiz3Page{
  @ViewChild('mySlider') slides : IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  constructor(private alertCtrl: AlertController) {}

  async correctAnswer(){
    await this.alertCtrl.create({
    header: "Congratulation!",
    subHeader:"That answer is correct.",
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "Okay"
    }
    ]
    }).then(res => res.present());
}

// question1
async wrongAnswer1(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : X.Y",
  message:"Explanation: (.) symbol represent AND in boolean",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question2
async wrongAnswer2(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : 1",
message:"Explanation: Symbolic Logic uses values, either 0 or 1.",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question3
async wrongAnswer3(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : the result of a logic function using a table",
message:"Explanation: Truth Tables are constructed by defining all possible combinations of the inputs of a function, and then calculating the output for each comcination in turn",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question4
async wrongAnswer4(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : True if any inputs are true",
message:"Explanation: A OR B is true if *A is true* OR *B is true*",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Cancel"
}
]
}).then(res => res.present());
}

// question5
async wrongAnswer5(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : NOR",
message:"Explanation: The figure shows combination of NOT and OR",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

}
