import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides, AlertController } from '@ionic/angular';


@Component({
  selector: 'app-quiz2',
  templateUrl: './quiz2.page.html',
  styleUrls: ['./quiz2.page.scss'],
})

export class Quiz2Page{
  @ViewChild('mySlider') slides : IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  constructor(private alertCtrl: AlertController) {}

  async correctAnswer(){
      await this.alertCtrl.create({
      header: "Congratulation!",
      subHeader:"That answer is correct.",
      // inputs: [
      //   { type: 'text', name:'promo', placeholder: "Promo code"}
      // ],
      buttons:[
      //   { text: "Next", handler: (res) => {
      //      console.log(res.promo);
      //   } 
      // },
      {
        text: "Okay"
      }
      ]
      }).then(res => res.present());
  }

// question1
  async wrongAnswer1(){
    await this.alertCtrl.create({
    header: "Study this one!",
    subHeader:"Correct answer : Base 8",
    message:"Explanation: Follows the numbering system",
    
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "Okay"
    }
    ]
    }).then(res => res.present());
}

// question2
async wrongAnswer2(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : Numbers without signs",
  message:"Explanation: Only integer number without any signs",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question3
async wrongAnswer3(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : 10 110 011",
  message:"Explanation: Follows the steps in addition of binary numbers",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question4
async wrongAnswer4(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : plus(+) or minus(-)",
  message:"Explanation: Signed numbers are integer with positive or negative value",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question5
async wrongAnswer5(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : plus(+ve)",
  message:"Explanation: null",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

}



