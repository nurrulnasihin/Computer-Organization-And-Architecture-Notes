import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap6q3PageRoutingModule } from './chap6q3-routing.module';

import { Chap6q3Page } from './chap6q3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap6q3PageRoutingModule
  ],
  declarations: [Chap6q3Page]
})
export class Chap6q3PageModule {}
