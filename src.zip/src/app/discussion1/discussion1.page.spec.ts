import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Discussion1Page } from './discussion1.page';

describe('Discussion1Page', () => {
  let component: Discussion1Page;
  let fixture: ComponentFixture<Discussion1Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Discussion1Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Discussion1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
