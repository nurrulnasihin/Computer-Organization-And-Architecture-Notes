import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Discussion1PageRoutingModule } from './discussion1-routing.module';

import { Discussion1Page } from './discussion1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Discussion1PageRoutingModule
  ],
  declarations: [Discussion1Page]
})
export class Discussion1PageModule {}
