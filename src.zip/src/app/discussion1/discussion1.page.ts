import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discussion1',
  templateUrl: './discussion1.page.html',
  styleUrls: ['./discussion1.page.scss'],
})
export class Discussion1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
