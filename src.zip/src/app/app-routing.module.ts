import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'forgotpassword',
    loadChildren: () => import('./forgotpassword/forgotpassword.module').then( m => m.ForgotpasswordPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'firstpage',
    loadChildren: () => import('./firstpage/firstpage.module').then( m => m.FirstpagePageModule)
  },
  {
    path: 'chapters',
    loadChildren: () => import('./chapters/chapters.module').then( m => m.ChaptersPageModule)
  },
  {
    path: 'chapter1',
    loadChildren: () => import('./chapter1/chapter1.module').then( m => m.Chapter1PageModule)
  },
  {
    path: 'coursedetails',
    loadChildren: () => import('./coursedetails/coursedetails.module').then( m => m.CoursedetailsPageModule)
  },
  {
    path: 'chapter2',
    loadChildren: () => import('./chapter2/chapter2.module').then( m => m.Chapter2PageModule)
  },
  {
    path: 'chapter3',
    loadChildren: () => import('./chapter3/chapter3.module').then( m => m.Chapter3PageModule)
  },
  {
    path: 'chapter4',
    loadChildren: () => import('./chapter4/chapter4.module').then( m => m.Chapter4PageModule)
  },
  {
    path: 'chapter5',
    loadChildren: () => import('./chapter5/chapter5.module').then( m => m.Chapter5PageModule)
  },
  {
    path: 'chapter6',
    loadChildren: () => import('./chapter6/chapter6.module').then( m => m.Chapter6PageModule)
  },
  {
    path: 'chapter7',
    loadChildren: () => import('./chapter7/chapter7.module').then( m => m.Chapter7PageModule)
  },
  {
    path: 'exercise',
    loadChildren: () => import('./exercise/exercise.module').then( m => m.ExercisePageModule)
  },
  {
    path: 'quiz',
    loadChildren: () => import('./quiz/quiz.module').then( m => m.QuizPageModule)
  },
  {
    path: 'exercise1',
    loadChildren: () => import('./exercise1/exercise1.module').then( m => m.Exercise1PageModule)
  },
  {
    path: 'exercise2',
    loadChildren: () => import('./exercise2/exercise2.module').then( m => m.Exercise2PageModule)
  },
  {
    path: 'exercise3',
    loadChildren: () => import('./exercise3/exercise3.module').then( m => m.Exercise3PageModule)
  },
  {
    path: 'exercise4',
    loadChildren: () => import('./exercise4/exercise4.module').then( m => m.Exercise4PageModule)
  },
  {
    path: 'exercise5',
    loadChildren: () => import('./exercise5/exercise5.module').then( m => m.Exercise5PageModule)
  },
  {
    path: 'exercise6',
    loadChildren: () => import('./exercise6/exercise6.module').then( m => m.Exercise6PageModule)
  },
  {
    path: 'exercise7',
    loadChildren: () => import('./exercise7/exercise7.module').then( m => m.Exercise7PageModule)
  },
  {
    path: 'quiz1',
    loadChildren: () => import('./quiz1/quiz1.module').then( m => m.Quiz1PageModule)
  },
  {
    path: 'quiz2',
    loadChildren: () => import('./quiz2/quiz2.module').then( m => m.Quiz2PageModule)
  },
  {
    path: 'quiz3',
    loadChildren: () => import('./quiz3/quiz3.module').then( m => m.Quiz3PageModule)
  },
  {
    path: 'quiz4',
    loadChildren: () => import('./quiz4/quiz4.module').then( m => m.Quiz4PageModule)
  },
  {
    path: 'quiz5',
    loadChildren: () => import('./quiz5/quiz5.module').then( m => m.Quiz5PageModule)
  },
  {
    path: 'quiz6',
    loadChildren: () => import('./quiz6/quiz6.module').then( m => m.Quiz6PageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'forum',
    loadChildren: () => import('./forum/forum.module').then( m => m.ForumPageModule)
  },
  
  
 
  
  {
    path: 'firebase',
    loadChildren: () => import('./services/firebase/firebase.module').then( m => m.FirebasePageModule)
  },
  {
    path: 'services',
    loadChildren: () => import('./services/services.module').then( m => m.ServicesPageModule)
  },
  {
    path: 'discussion1',
    loadChildren: () => import('./discussion1/discussion1.module').then( m => m.Discussion1PageModule)
  },
  {
    path: 'answers/:id',
    loadChildren: () => import('./answers/answers.module').then( m => m.AnswersPageModule)
  },
  {
    path: 'questionanswer',
    loadChildren: () => import('./questionanswer/questionanswer.module').then( m => m.QuestionanswerPageModule)
  },
  {
    path: 'answer1',
    loadChildren: () => import('./answer1/answer1.module').then( m => m.Answer1PageModule)
  },
  {
    path: 'c1q1',
    loadChildren: () => import('./c1q1/c1q1.module').then( m => m.C1q1PageModule)
  },
  {
    path: 'c1q2',
    loadChildren: () => import('./c1q2/c1q2.module').then( m => m.C1q2PageModule)
  },
  {
    path: 'c1q3',
    loadChildren: () => import('./c1q3/c1q3.module').then( m => m.C1q3PageModule)
  },
  {
    path: 'chap3q1',
    loadChildren: () => import('./chap3q1/chap3q1.module').then( m => m.Chap3q1PageModule)
  },
  {
    path: 'chap3q2',
    loadChildren: () => import('./chap3q2/chap3q2.module').then( m => m.Chap3q2PageModule)
  },
  {
    path: 'chap3q3',
    loadChildren: () => import('./chap3q3/chap3q3.module').then( m => m.Chap3q3PageModule)
  },
  {
    path: 'chap4q1',
    loadChildren: () => import('./chap4q1/chap4q1.module').then( m => m.Chap4q1PageModule)
  },
  {
    path: 'chap4q2',
    loadChildren: () => import('./chap4q2/chap4q2.module').then( m => m.Chap4q2PageModule)
  },
  {
    path: 'chap4q3',
    loadChildren: () => import('./chap4q3/chap4q3.module').then( m => m.Chap4q3PageModule)
  },
  {
    path: 'chap5q1',
    loadChildren: () => import('./chap5q1/chap5q1.module').then( m => m.Chap5q1PageModule)
  },
  {
    path: 'chap5q2',
    loadChildren: () => import('./chap5q2/chap5q2.module').then( m => m.Chap5q2PageModule)
  },
  {
    path: 'chap5q3',
    loadChildren: () => import('./chap5q3/chap5q3.module').then( m => m.Chap5q3PageModule)
  },
  {
    path: 'chap6q1',
    loadChildren: () => import('./chap6q1/chap6q1.module').then( m => m.Chap6q1PageModule)
  },
  {
    path: 'chap6q2',
    loadChildren: () => import('./chap6q2/chap6q2.module').then( m => m.Chap6q2PageModule)
  },
  {
    path: 'chap6q3',
    loadChildren: () => import('./chap6q3/chap6q3.module').then( m => m.Chap6q3PageModule)
  },
  {
    path: 'chap6q4',
    loadChildren: () => import('./chap6q4/chap6q4.module').then( m => m.Chap6q4PageModule)
  },
  {
    path: 'chap1q1',
    loadChildren: () => import('./chap1q1/chap1q1.module').then( m => m.Chap1q1PageModule)
  },
  {
    path: 'chap1q2',
    loadChildren: () => import('./chap1q2/chap1q2.module').then( m => m.Chap1q2PageModule)
  },
  {
    path: 'chap1q3',
    loadChildren: () => import('./chap1q3/chap1q3.module').then( m => m.Chap1q3PageModule)
  },
  {
    path: 'chap1q4',
    loadChildren: () => import('./chap1q4/chap1q4.module').then( m => m.Chap1q4PageModule)
  },
  {
    path: 'chap1q5',
    loadChildren: () => import('./chap1q5/chap1q5.module').then( m => m.Chap1q5PageModule)
  },
  {
    path: 'chap1q6',
    loadChildren: () => import('./chap1q6/chap1q6.module').then( m => m.Chap1q6PageModule)
  },
  {
    path: 'chap1q7',
    loadChildren: () => import('./chap1q7/chap1q7.module').then( m => m.Chap1q7PageModule)
  },
  {
    path: 'announcement',
    loadChildren: () => import('./announcement/announcement.module').then( m => m.AnnouncementPageModule)
  },
  {
    path: 'announcements',
    loadChildren: () => import('./announcements/announcements.module').then( m => m.AnnouncementsPageModule)
  },
  {
    path: 'post',
    loadChildren: () => import('./post/post.module').then( m => m.PostPageModule)
  },
  {
    path: 'posts',
    loadChildren: () => import('./posts/posts.module').then( m => m.PostsPageModule)
  },
  {
    path: 'learn',
    loadChildren: () => import('./learn/categories/learn-categories.module').then(m => m.LearnCategoriesModule)
  },
  {
    path: 'learn/:category',
    loadChildren: () => import('./learn/category/learn-category.module').then(m => m.LearnCategoryModule)
  },
  {
    path: 'questions/:id/:slug',
    loadChildren: () => import('./questions/questions.module').then(m => m.QuestionsModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile.module').then( m => m.ProfilePageModule)
  },

  
 
  
 
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
