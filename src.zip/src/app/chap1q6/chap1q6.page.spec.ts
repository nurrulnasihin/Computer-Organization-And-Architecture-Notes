import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap1q6Page } from './chap1q6.page';

describe('Chap1q6Page', () => {
  let component: Chap1q6Page;
  let fixture: ComponentFixture<Chap1q6Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap1q6Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap1q6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
