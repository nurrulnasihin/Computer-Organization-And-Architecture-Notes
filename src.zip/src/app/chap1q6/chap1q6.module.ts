import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q6PageRoutingModule } from './chap1q6-routing.module';

import { Chap1q6Page } from './chap1q6.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q6PageRoutingModule
  ],
  declarations: [Chap1q6Page]
})
export class Chap1q6PageModule {}
