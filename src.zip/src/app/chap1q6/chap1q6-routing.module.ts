import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap1q6Page } from './chap1q6.page';

const routes: Routes = [
  {
    path: '',
    component: Chap1q6Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap1q6PageRoutingModule {}
