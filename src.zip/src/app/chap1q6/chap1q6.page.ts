import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q6',
  templateUrl: './chap1q6.page.html',
  styleUrls: ['./chap1q6.page.scss'],
})
export class Chap1q6Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
