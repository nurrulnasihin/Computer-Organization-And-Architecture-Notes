import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap1q5Page } from './chap1q5.page';

const routes: Routes = [
  {
    path: '',
    component: Chap1q5Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap1q5PageRoutingModule {}
