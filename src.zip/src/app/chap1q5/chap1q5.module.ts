import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q5PageRoutingModule } from './chap1q5-routing.module';

import { Chap1q5Page } from './chap1q5.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q5PageRoutingModule
  ],
  declarations: [Chap1q5Page]
})
export class Chap1q5PageModule {}
