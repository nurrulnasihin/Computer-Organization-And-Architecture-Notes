import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q5',
  templateUrl: './chap1q5.page.html',
  styleUrls: ['./chap1q5.page.scss'],
})
export class Chap1q5Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
