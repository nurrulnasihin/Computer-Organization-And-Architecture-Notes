import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap1q5Page } from './chap1q5.page';

describe('Chap1q5Page', () => {
  let component: Chap1q5Page;
  let fixture: ComponentFixture<Chap1q5Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap1q5Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap1q5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
