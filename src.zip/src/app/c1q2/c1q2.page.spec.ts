import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { C1q2Page } from './c1q2.page';

describe('C1q2Page', () => {
  let component: C1q2Page;
  let fixture: ComponentFixture<C1q2Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ C1q2Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(C1q2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
