import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { C1q2PageRoutingModule } from './c1q2-routing.module';

import { C1q2Page } from './c1q2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    C1q2PageRoutingModule
  ],
  declarations: [C1q2Page]
})
export class C1q2PageModule {}
