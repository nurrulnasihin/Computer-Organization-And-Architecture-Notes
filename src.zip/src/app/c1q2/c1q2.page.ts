import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c1q2',
  templateUrl: './c1q2.page.html',
  styleUrls: ['./c1q2.page.scss'],
})
export class C1q2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
