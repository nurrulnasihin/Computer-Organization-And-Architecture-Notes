import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exercise6',
  templateUrl: './exercise6.page.html',
  styleUrls: ['./exercise6.page.scss'],
})
export class Exercise6Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
