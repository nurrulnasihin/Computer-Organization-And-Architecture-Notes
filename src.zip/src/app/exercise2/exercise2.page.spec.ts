import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Exercise2Page } from './exercise2.page';

describe('Exercise2Page', () => {
  let component: Exercise2Page;
  let fixture: ComponentFixture<Exercise2Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Exercise2Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Exercise2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
