import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap4q2',
  templateUrl: './chap4q2.page.html',
  styleUrls: ['./chap4q2.page.scss'],
})
export class Chap4q2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
