import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap4q2Page } from './chap4q2.page';

const routes: Routes = [
  {
    path: '',
    component: Chap4q2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap4q2PageRoutingModule {}
