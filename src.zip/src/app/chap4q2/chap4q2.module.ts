import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap4q2PageRoutingModule } from './chap4q2-routing.module';

import { Chap4q2Page } from './chap4q2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap4q2PageRoutingModule
  ],
  declarations: [Chap4q2Page]
})
export class Chap4q2PageModule {}
