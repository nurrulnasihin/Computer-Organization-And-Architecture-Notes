import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap3q3Page } from './chap3q3.page';

describe('Chap3q3Page', () => {
  let component: Chap3q3Page;
  let fixture: ComponentFixture<Chap3q3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap3q3Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap3q3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
