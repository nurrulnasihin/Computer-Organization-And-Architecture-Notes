import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap3q3PageRoutingModule } from './chap3q3-routing.module';

import { Chap3q3Page } from './chap3q3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap3q3PageRoutingModule
  ],
  declarations: [Chap3q3Page]
})
export class Chap3q3PageModule {}
