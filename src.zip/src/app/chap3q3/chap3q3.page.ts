import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap3q3',
  templateUrl: './chap3q3.page.html',
  styleUrls: ['./chap3q3.page.scss'],
})
export class Chap3q3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
