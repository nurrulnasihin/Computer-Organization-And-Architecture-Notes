import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { C1q1PageRoutingModule } from './c1q1-routing.module';

import { C1q1Page } from './c1q1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    C1q1PageRoutingModule
  ],
  declarations: [C1q1Page]
})
export class C1q1PageModule {}
