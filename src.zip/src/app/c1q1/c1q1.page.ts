import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c1q1',
  templateUrl: './c1q1.page.html',
  styleUrls: ['./c1q1.page.scss'],
})
export class C1q1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
