import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides, AlertController } from '@ionic/angular';


@Component({
  selector: 'app-quiz4',
  templateUrl: './quiz4.page.html',
  styleUrls: ['./quiz4.page.scss'],
})
export class Quiz4Page{
  @ViewChild('mySlider') slides : IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  constructor(private alertCtrl: AlertController) {}

  async correctAnswer(){
    await this.alertCtrl.create({
    header: "Congratulation!",
    subHeader:"That answer is correct.",
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "Okay"
    }
    ]
    }).then(res => res.present());
}

// question1
async wrongAnswer1(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : Data Bus",
  message:"Explanation: System Bus only contain 3 type of bus which are data bus, address bus and control bus",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question2
async wrongAnswer2(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : ALU, CU, Registers",
message:"Explanation: These are the components in CPU ",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question3
async wrongAnswer3(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : Last In First Out",
message:"Explanation: Based on the figure, the value 6 is the last one to be pushed in but it is the first one popped out ",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question4
async wrongAnswer4(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : True",
message:"Explanation: Register in CPU performs two roles: User Visible Register & Control And Status Register",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question5
async wrongAnswer5(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : Instruction Cycle",
message:"Explanation: null",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}
//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}
}
