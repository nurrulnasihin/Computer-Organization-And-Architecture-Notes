import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap5q1Page } from './chap5q1.page';

const routes: Routes = [
  {
    path: '',
    component: Chap5q1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap5q1PageRoutingModule {}
