import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap5q1',
  templateUrl: './chap5q1.page.html',
  styleUrls: ['./chap5q1.page.scss'],
})
export class Chap5q1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
