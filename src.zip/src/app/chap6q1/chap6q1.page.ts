import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap6q1',
  templateUrl: './chap6q1.page.html',
  styleUrls: ['./chap6q1.page.scss'],
})
export class Chap6q1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
