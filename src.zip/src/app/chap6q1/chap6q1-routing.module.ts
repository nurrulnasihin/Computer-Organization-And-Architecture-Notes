import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap6q1Page } from './chap6q1.page';

const routes: Routes = [
  {
    path: '',
    component: Chap6q1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap6q1PageRoutingModule {}
