import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap6q1PageRoutingModule } from './chap6q1-routing.module';

import { Chap6q1Page } from './chap6q1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap6q1PageRoutingModule
  ],
  declarations: [Chap6q1Page]
})
export class Chap6q1PageModule {}
