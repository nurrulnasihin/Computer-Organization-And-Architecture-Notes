import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap4q1PageRoutingModule } from './chap4q1-routing.module';

import { Chap4q1Page } from './chap4q1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap4q1PageRoutingModule
  ],
  declarations: [Chap4q1Page]
})
export class Chap4q1PageModule {}
