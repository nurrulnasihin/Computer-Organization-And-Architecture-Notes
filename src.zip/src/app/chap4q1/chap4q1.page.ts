import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap4q1',
  templateUrl: './chap4q1.page.html',
  styleUrls: ['./chap4q1.page.scss'],
})
export class Chap4q1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
