import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap4q1Page } from './chap4q1.page';

describe('Chap4q1Page', () => {
  let component: Chap4q1Page;
  let fixture: ComponentFixture<Chap4q1Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap4q1Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap4q1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
