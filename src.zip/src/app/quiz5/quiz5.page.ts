import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides,AlertController } from '@ionic/angular';


@Component({
  selector: 'app-quiz5',
  templateUrl: './quiz5.page.html',
  styleUrls: ['./quiz5.page.scss'],
})
export class Quiz5Page{
  @ViewChild('mySlider') slides : IonSlides;

  swipeNext() {
    this.slides.slideNext();
  }

  constructor(private alertCtrl: AlertController) {}
  async correctAnswer(){
    await this.alertCtrl.create({
    header: "Congratulation!",
    subHeader:"That answer is correct.",
    // inputs: [
    //   { type: 'text', name:'promo', placeholder: "Promo code"}
    // ],
    buttons:[
    //   { text: "Next", handler: (res) => {
    //      console.log(res.promo);
    //   } 
    // },
    {
      text: "Okay"
    }
    ]
    }).then(res => res.present());
}

// question1
async wrongAnswer1(){
  await this.alertCtrl.create({
  header: "Study this one!",
  subHeader:"Correct answer : External",
  message:"Explanation: Computer Memory System are divided into 2 parts: Internal Memory/External Memory",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}

// question2
async wrongAnswer2(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : False",
message:"Explanation: Direct mapping maps each block of main memory into only ONE possible cache line",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question3
async wrongAnswer3(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : No of block x block size",
message:"Explanation: Formula given - Main Memory = No of block x block size",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question4
async wrongAnswer4(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : holds data recently read or written to & from a hard disk",
message:"Explanation: null",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}

// question5
async wrongAnswer5(){
await this.alertCtrl.create({
header: "Study this one!",
subHeader:"Correct answer : all of the above",
message:"Explanation: null",

// inputs: [
//   { type: 'text', name:'promo', placeholder: "Promo code"}
// ],
buttons:[
//   { text: "Next", handler: (res) => {
//      console.log(res.promo);
//   } 
// },
{
  text: "Okay"
}
]
}).then(res => res.present());
}
//submit
// question5
async submit(){
  await this.alertCtrl.create({
  header: "Thank You!",
  subHeader:"You did a great job answering this quiz.",
  
  // inputs: [
  //   { type: 'text', name:'promo', placeholder: "Promo code"}
  // ],
  buttons:[
  //   { text: "Next", handler: (res) => {
  //      console.log(res.promo);
  //   } 
  // },
  {
    text: "Okay"
  }
  ]
  }).then(res => res.present());
}
}
