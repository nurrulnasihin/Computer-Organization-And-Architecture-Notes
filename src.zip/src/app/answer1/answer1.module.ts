import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Answer1PageRoutingModule } from './answer1-routing.module';

import { Answer1Page } from './answer1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Answer1PageRoutingModule
  ],
  declarations: [Answer1Page]
})
export class Answer1PageModule {}
