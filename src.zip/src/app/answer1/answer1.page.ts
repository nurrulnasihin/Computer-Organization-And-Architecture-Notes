import { Component, OnInit } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-answer1',
  templateUrl: './answer1.page.html',
  styleUrls: ['./answer1.page.scss'],
  providers: [NavParams]
})
export class Answer1Page implements OnInit {
dataReceived:string="";
  constructor(public activatedRoute: ActivatedRoute, public navCtrl: NavController, public navParams: NavParams) 
  {
    this.activatedRoute.queryParams.subscribe ((data) => {
      this.dataReceived = JSON.stringify(data);

    })
   }

ngOnInit(){

}

  ionViewDidLoad(){
    console.log('ionViewDidLoad Answer1Page');
  }

}
