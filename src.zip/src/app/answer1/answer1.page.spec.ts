import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Answer1Page } from './answer1.page';

describe('Answer1Page', () => {
  let component: Answer1Page;
  let fixture: ComponentFixture<Answer1Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Answer1Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Answer1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
