import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap1q7Page } from './chap1q7.page';

describe('Chap1q7Page', () => {
  let component: Chap1q7Page;
  let fixture: ComponentFixture<Chap1q7Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap1q7Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap1q7Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
