import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q7',
  templateUrl: './chap1q7.page.html',
  styleUrls: ['./chap1q7.page.scss'],
})
export class Chap1q7Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
