import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q7PageRoutingModule } from './chap1q7-routing.module';

import { Chap1q7Page } from './chap1q7.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q7PageRoutingModule
  ],
  declarations: [Chap1q7Page]
})
export class Chap1q7PageModule {}
