import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap1q7Page } from './chap1q7.page';

const routes: Routes = [
  {
    path: '',
    component: Chap1q7Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap1q7PageRoutingModule {}
