import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Chap1q1Page } from './chap1q1.page';

const routes: Routes = [
  {
    path: '',
    component: Chap1q1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Chap1q1PageRoutingModule {}
