import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap1q1PageRoutingModule } from './chap1q1-routing.module';

import { Chap1q1Page } from './chap1q1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap1q1PageRoutingModule
  ],
  declarations: [Chap1q1Page]
})
export class Chap1q1PageModule {}
