import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap1q1',
  templateUrl: './chap1q1.page.html',
  styleUrls: ['./chap1q1.page.scss'],
})
export class Chap1q1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
