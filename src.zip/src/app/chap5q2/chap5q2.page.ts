import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap5q2',
  templateUrl: './chap5q2.page.html',
  styleUrls: ['./chap5q2.page.scss'],
})
export class Chap5q2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
