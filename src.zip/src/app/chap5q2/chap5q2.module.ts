import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap5q2PageRoutingModule } from './chap5q2-routing.module';

import { Chap5q2Page } from './chap5q2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap5q2PageRoutingModule
  ],
  declarations: [Chap5q2Page]
})
export class Chap5q2PageModule {}
