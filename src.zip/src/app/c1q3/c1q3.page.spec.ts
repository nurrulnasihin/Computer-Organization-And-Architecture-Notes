import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { C1q3Page } from './c1q3.page';

describe('C1q3Page', () => {
  let component: C1q3Page;
  let fixture: ComponentFixture<C1q3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ C1q3Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(C1q3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
