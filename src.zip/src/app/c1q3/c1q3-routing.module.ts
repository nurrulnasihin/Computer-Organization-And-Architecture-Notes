import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { C1q3Page } from './c1q3.page';

const routes: Routes = [
  {
    path: '',
    component: C1q3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class C1q3PageRoutingModule {}
