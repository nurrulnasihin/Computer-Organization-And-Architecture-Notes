import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c1q3',
  templateUrl: './c1q3.page.html',
  styleUrls: ['./c1q3.page.scss'],
})
export class C1q3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
