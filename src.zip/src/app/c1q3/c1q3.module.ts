import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { C1q3PageRoutingModule } from './c1q3-routing.module';

import { C1q3Page } from './c1q3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    C1q3PageRoutingModule
  ],
  declarations: [C1q3Page]
})
export class C1q3PageModule {}
