import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap3q1PageRoutingModule } from './chap3q1-routing.module';

import { Chap3q1Page } from './chap3q1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap3q1PageRoutingModule
  ],
  declarations: [Chap3q1Page]
})
export class Chap3q1PageModule {}
