import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap3q1Page } from './chap3q1.page';

describe('Chap3q1Page', () => {
  let component: Chap3q1Page;
  let fixture: ComponentFixture<Chap3q1Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap3q1Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap3q1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
