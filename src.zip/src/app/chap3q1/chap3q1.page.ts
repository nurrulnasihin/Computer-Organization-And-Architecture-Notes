import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap3q1',
  templateUrl: './chap3q1.page.html',
  styleUrls: ['./chap3q1.page.scss'],
})
export class Chap3q1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
