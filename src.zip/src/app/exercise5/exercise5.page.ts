import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exercise5',
  templateUrl: './exercise5.page.html',
  styleUrls: ['./exercise5.page.scss'],
})
export class Exercise5Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
