import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chap4q3',
  templateUrl: './chap4q3.page.html',
  styleUrls: ['./chap4q3.page.scss'],
})
export class Chap4q3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
