import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Chap4q3Page } from './chap4q3.page';

describe('Chap4q3Page', () => {
  let component: Chap4q3Page;
  let fixture: ComponentFixture<Chap4q3Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Chap4q3Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Chap4q3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
