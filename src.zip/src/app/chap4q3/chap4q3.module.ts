import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Chap4q3PageRoutingModule } from './chap4q3-routing.module';

import { Chap4q3Page } from './chap4q3.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Chap4q3PageRoutingModule
  ],
  declarations: [Chap4q3Page]
})
export class Chap4q3PageModule {}
