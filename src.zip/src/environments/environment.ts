// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  API_URL: 'https://q-a-nest-api.ionicthemes.com/',

  firebaseConfig : {
    apiKey: "AIzaSyCEIg2nNLLZHzSpLt1eUz_gom6g7Wv7E9Y",
    authDomain: "fypnotes.firebaseapp.com",
    databaseURL: "https://fypnotes.firebaseio.com",
    projectId: "fypnotes",
    storageBucket: "fypnotes.appspot.com",
    messagingSenderId: "484864996033",
    appId: "1:484864996033:web:135c4b5eb58068782a1a40",
    measurementId: "G-7Q5Z8B0ZX3"
  }

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
